const sql = require('mssql/msnodesqlv8');

const config = {
  server: 'localhost\\SQLEXPRESS',  
  database: 'Ecommerce',
  driver: 'ODBC Driver 18 for SQL Server',
  options: {
    trustedConnection: true      
  }
};

const poolPromise = new sql.ConnectionPool(config)
  .connect()
  .then(pool => {
    console.log('Connected to SQL Server Express with Windows Authentication');
    return pool;
  })
  .catch(err => console.log('DB Connection Error:', err));

module.exports = poolPromise;
