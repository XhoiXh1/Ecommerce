const express = require('express');
const router = express.Router();
const poolPromise = require('../db');
const sql = require('mssql');

router.get('/', async (req, res) => {
  const pool = await poolPromise;
  const result = await pool.request().query('SELECT * FROM Klienti');
  res.json(result.recordset);
});

router.post('/', async (req, res) => {
  const { Emri, Email, Fjalekalimi, Adresa } = req.body;
  const pool = await poolPromise;
  await pool.request()
    .input('Emri', sql.NVarChar, Emri)
    .input('Email', sql.NVarChar, Email)
    .input('Fjalekalimi', sql.NVarChar, Fjalekalimi)
    .input('Adresa', sql.NVarChar, Adresa)
    .query('INSERT INTO Klienti (Emri, Email, Fjalekalimi, Adresa) VALUES (@Emri,@Email,@Fjalekalimi,@Adresa)');
  res.json({ message: "Klienti u shtua!" });
});

module.exports = router;
