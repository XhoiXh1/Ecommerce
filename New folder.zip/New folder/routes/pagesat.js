const express = require('express');
const router = express.Router();
const poolPromise = require('../db');
const sql = require('mssql');

router.get('/', async (req, res) => {
  const pool = await poolPromise;
  const result = await pool.request().query('SELECT * FROM Pagesa');
  res.json(result.recordset);
});

router.post('/', async (req, res) => {
  const { PorosiID, Metoda, Shuma } = req.body;
  const pool = await poolPromise;

  await pool.request()
    .input('PorosiID', sql.Int, PorosiID)
    .input('Metoda', sql.NVarChar, Metoda)
    .input('Shuma', sql.Decimal(10,2), Shuma)
    .query('INSERT INTO Pagesa (PorosiID, Metoda, Shuma) VALUES (@PorosiID,@Metoda,@Shuma)');

  await pool.request()
    .input('PorosiID', sql.Int, PorosiID)
    .query("UPDATE Porosia SET Statusi='Perfunduar' WHERE PorosiID=@PorosiID");

  res.json({ message: "Pagesa u regjistrua dhe porosia u përditësua!" });
});

module.exports = router;
