const express = require('express');
const router = express.Router();
const poolPromise = require('../db');
const sql = require('mssql');

router.get('/', async (req, res) => {
  const pool = await poolPromise;
  const result = await pool.request().query('SELECT * FROM Porosia');
  res.json(result.recordset);
});

router.post('/', async (req, res) => {
  const { KlientID, Produktet } = req.body; 

  const pool = await poolPromise;

  let total = 0;
  for(const p of Produktet){
    const prod = await pool.request()
      .input('pid', sql.Int, p.ProduktID)
      .query('SELECT Cmimi FROM Produkti WHERE ProduktID=@pid');
    total += prod.recordset[0].Cmimi * p.Sasia;
  }

const resultPorosi = await pool.request()
    .input('KlientID', sql.Int, KlientID)
    .input('Statusi', sql.NVarChar, 'NeProces')
    .input('Totali', sql.Decimal(10,2), total)
    .query('INSERT INTO Porosia (KlientID, Statusi, Totali) OUTPUT INSERTED.PorosiID VALUES (@KlientID,@Statusi,@Totali)');

  const PorosiID = resultPorosi.recordset[0].PorosiID;

  for(const p of Produktet){
    const prod = await pool.request()
      .input('pid', sql.Int, p.ProduktID)
      .query('SELECT Cmimi FROM Produkti WHERE ProduktID=@pid');
    const cmimi = prod.recordset[0].Cmimi;

    await pool.request()
      .input('PorosiID', sql.Int, PorosiID)
      .input('ProduktID', sql.Int, p.ProduktID)
      .input('Sasia', sql.Int, p.Sasia)
      .input('CmimiNeBlerje', sql.Decimal(10,2), cmimi)
      .query('INSERT INTO PorosiDetaje (PorosiID, ProduktID, Sasia, CmimiNeBlerje) VALUES (@PorosiID,@ProduktID,@Sasia,@CmimiNeBlerje)');
  }

  res.json({ message: "Porosia u krijua!", PorosiID });
});

module.exports = router;
