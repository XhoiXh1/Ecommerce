const express = require('express');
const router = express.Router();
const poolPromise = require('../db');
const sql = require('mssql');

router.get('/', async (req, res) => {
  const pool = await poolPromise;
  const result = await pool.request().query('SELECT * FROM Produkti');
  res.json(result.recordset);
});

router.post('/', async (req, res) => {
  const { Emri, Pershkrimi, Cmimi, Stoku, Available } = req.body;
  const pool = await poolPromise;
  await pool.request()
    .input('Emri', sql.NVarChar, Emri)
    .input('Pershkrimi', sql.NVarChar, Pershkrimi)
    .input('Cmimi', sql.Decimal(10,2), Cmimi)
    .input('Stoku', sql.Int, Stoku)
    .input('Available', sql.Bit, Available)
    .query('INSERT INTO Produkti (Emri, Pershkrimi, Cmimi, Stoku, Available) VALUES (@Emri,@Pershkrimi,@Cmimi,@Stoku,@Available)');
  res.json({ message: "Produkti u shtua!" });
});

module.exports = router;
