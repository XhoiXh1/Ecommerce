const express = require('express');
const app = express();
app.use(express.json());

app.use('/api/klientet', require('./routes/klientet'));
app.use('/api/produkte', require('./routes/produktet'));
app.use('/api/porosi', require('./routes/porosite'));
app.use('/api/pagesa', require('./routes/pagesat'));

app.listen(3000, () => console.log("API running on port 3000"));
